from enum import Enum


class Repo(Enum):
	Multilib = "multilib"
	Testing = "testing"
